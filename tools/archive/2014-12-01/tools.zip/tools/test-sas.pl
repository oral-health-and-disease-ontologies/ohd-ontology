open(my $sasfile,"<",$ARGV[0]) or usage();

sub getheaders {
  $index = 0;
  $headerflag = 0;

  while ($line = <$sasfile>) {
    # if header flag is on, put variable names in header list
    if ($headerflag == 1) {
      chomp($line);
      $line =~ s/^\s+|\s+$//g ;     # remove both leading and trailing whitespace
      @headers[$index] = "\"$line\"";
      $index++;
    }

    # when we see the line "INPUT" start collecting headers
    if ($line =~ /INPUT/) {
      $headerflag = 1;
    }

    # when we see the line that ends with a "$" stop collecting headers
    if (($headerflag == 1) && ($line =~ /(.|\s)*\$/)) {
      $headerflag = 0;

      # remove '$' from end of line by searching up the first word boundary
      $line =~ s/^\s+|\s+$//g ;     # remove both leading and trailing whitespace
      ($temp) = $line =~ m/(.*\b)/;
      @headers[$index - 1] = "\"$temp\"";
    }
  }

  print "@headers \n";
}

getheaders();
